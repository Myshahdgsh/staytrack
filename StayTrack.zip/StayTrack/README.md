# StayTrack - Hostel Management System

StayTrack is a Java 17+ JavaFX desktop application for hostel administration. It includes login, dashboard analytics, student management, room management, allocation, fee tracking, report export, validation, JDBC services, and MySQL schema generation.

## Default Login

- Username: `admin`
- Password: `admin123`

## Requirements

- JDK 17 or newer
- Maven 3.8+
- MySQL 8+

## Run

1. Start MySQL.
2. Update database credentials if needed:

```bash
mvn javafx:run -Dstaytrack.db.user=root -Dstaytrack.db.password=your_password
```

The app automatically creates `staytrack_db` and seed admin/room records at startup. You can also run `staytrack_db.sql` manually in MySQL Workbench or CLI.

## Project Structure

```text
StayTrack/
├── src/main/java/com/staytrack/controllers
├── src/main/java/com/staytrack/database
├── src/main/java/com/staytrack/models
├── src/main/java/com/staytrack/services
├── src/main/java/com/staytrack/util
├── src/main/resources/css
├── src/main/resources/images
├── src/test/java/com/staytrack
├── sql
├── reports
├── docs
├── pom.xml
├── README.md
└── staytrack_db.sql
```

## Main Features

- Secure admin login with remember-me storage.
- Dashboard cards and charts for student, room, income, and pending fee metrics.
- Student add, update, delete, search, and details through TableView selection.
- Room add, update, delete, availability/status management.
- Room allocation with capacity checks and automatic occupancy updates.
- Payment records with paid, pending, and partially paid status.
- CSV reports for students, room occupancy, payments, and pending fees.
- Print current report page with JavaFX printing.

## Build

```bash
mvn clean test
mvn javafx:run
```

## Database

Full schema is available in `staytrack_db.sql`. Additional sample data is in `sql/sample-data.sql`.

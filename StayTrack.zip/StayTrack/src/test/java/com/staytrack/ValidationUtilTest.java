package com.staytrack;

import com.staytrack.util.ValidationUtil;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ValidationUtilTest {
    @Test
    void validatesPhoneEmailAndMoney() {
        assertTrue(ValidationUtil.validPhone("01711111111"));
        assertFalse(ValidationUtil.validPhone("phone"));
        assertTrue(ValidationUtil.validEmail("admin@staytrack.local"));
        assertFalse(ValidationUtil.validEmail("broken-email"));
        assertTrue(ValidationUtil.nonNegative(BigDecimal.ZERO));
        assertFalse(ValidationUtil.nonNegative(new BigDecimal("-1")));
    }
}

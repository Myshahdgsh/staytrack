# Installation Guide

## 1. Install Tools

- Install JDK 17 or newer.
- Install Maven.
- Install MySQL 8 or newer.

## 2. Configure MySQL

Create a MySQL user or use `root`. The app uses these defaults:

- Host: `localhost`
- Port: `3306`
- Database: `staytrack_db`
- User: `root`
- Password: empty

Override them with JVM properties:

```bash
mvn javafx:run -Dstaytrack.db.host=localhost -Dstaytrack.db.port=3306 -Dstaytrack.db.user=root -Dstaytrack.db.password=your_password
```

## 3. Run Schema Manually

If automatic creation is not preferred:

```bash
mysql -u root -p < staytrack_db.sql
mysql -u root -p < sql/sample-data.sql
```

## 4. Start App

```bash
mvn javafx:run
```

Login with `admin` / `admin123`.

# Database Documentation

Database name: `staytrack_db`

## Tables

- `users`: admin login data and remember-me flag.
- `students`: student profile and guardian details.
- `rooms`: room capacity, rent, occupancy, and availability status.
- `allocations`: active and historical room assignments.
- `payments`: monthly fee/payment records.

## Relationships

- `allocations.student_id` references `students.id`.
- `allocations.room_id` references `rooms.id`.
- `payments.student_id` references `students.id`.

## Indexes

- Student name and phone indexes support search.
- Room number and status indexes support availability views.
- Payment status and month indexes support fee reports.

## ER Diagram

```mermaid
erDiagram
    USERS {
        int id PK
        varchar username UK
        varchar password
        varchar role
        boolean remember_me
    }
    STUDENTS {
        int id PK
        varchar full_name
        varchar father_name
        varchar mother_name
        varchar gender
        date date_of_birth
        varchar phone
        varchar email
        text address
        date admission_date
        varchar guardian_contact
    }
    ROOMS {
        int id PK
        varchar room_number UK
        varchar room_type
        int capacity
        int current_occupancy
        decimal monthly_rent
        varchar status
    }
    ALLOCATIONS {
        int id PK
        int student_id FK
        int room_id FK
        date allocation_date
        boolean active
    }
    PAYMENTS {
        int id PK
        int student_id FK
        varchar fee_month
        decimal amount
        date payment_date
        decimal due_amount
        varchar status
    }
    STUDENTS ||--o{ ALLOCATIONS : receives
    ROOMS ||--o{ ALLOCATIONS : hosts
    STUDENTS ||--o{ PAYMENTS : pays
```

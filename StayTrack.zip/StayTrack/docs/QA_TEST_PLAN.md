# QA Test Plan

## Unit Tests

- Validate phone number format.
- Validate email format.
- Validate payment amount boundaries.

## Integration Tests

Run with a local MySQL database:

1. Start MySQL.
2. Execute `staytrack_db.sql`.
3. Start the app.
4. Login with `admin/admin123`.
5. Add a student.
6. Add a room.
7. Allocate the student to the room.
8. Verify room occupancy increased.
9. Record a payment.
10. Export reports and verify CSV files in `reports`.

## Regression Checklist

- Login rejects invalid credentials.
- Student search finds by ID and name.
- Room allocation blocks full rooms.
- Vacating a room decreases occupancy.
- Payment due amount cannot be negative.
- Reports are generated without empty headers.

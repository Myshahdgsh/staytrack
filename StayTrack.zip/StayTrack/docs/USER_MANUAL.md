# User Manual

## Login

Open the app and sign in with the default admin account. Use remember me when working on a trusted machine.

## Dashboard

Dashboard cards show total students, occupied rooms, available rooms, monthly income, and pending payments. Charts summarize occupancy and payment health.

## Students

Use the Students page to add, update, delete, and search student profiles. Select a row to edit it. Phone and guardian contacts must contain 7-15 digits. Email must be valid when provided.

## Rooms

Use the Rooms page to manage room number, type, capacity, occupancy, rent, and status. Occupancy cannot exceed capacity.

## Allocation

Enter a Student ID and Room ID, then allocate a room. StayTrack prevents allocation when the selected room is full or unavailable. Vacating a student closes their active allocation and decreases room occupancy.

## Fees

Record monthly payments with amount, due amount, payment date, month, and status. Negative payments are blocked.

## Reports

Export CSV reports for student list, room occupancy, payments, and pending fees. Use Print Current Page for a quick hard copy.

# Class Diagram

```mermaid
classDiagram
    class App {
        +start(Stage)
        +main(String[])
    }
    class LoginController {
        +getView() Parent
    }
    class MainController {
        +getView() Parent
    }
    class DatabaseInitializer {
        +initialize()
        +getConnection() Connection
    }
    class AuthService {
        +login(String, String, boolean) boolean
    }
    class StudentService {
        +findAll(String) List~Student~
        +save(Student)
        +delete(int)
    }
    class RoomService {
        +findAll(String) List~Room~
        +save(Room)
        +delete(int)
    }
    class AllocationService {
        +allocate(int, int, LocalDate)
        +vacate(int)
    }
    class PaymentService {
        +findAll(String) List~Payment~
        +save(Payment)
    }
    class ReportService {
        +exportCsv(String, String, Path) Path
    }
    class Student
    class Room
    class Payment
    class Allocation
    App --> LoginController
    LoginController --> AuthService
    LoginController --> MainController
    MainController --> StudentService
    MainController --> RoomService
    MainController --> AllocationService
    MainController --> PaymentService
    MainController --> ReportService
    StudentService --> DatabaseInitializer
    RoomService --> DatabaseInitializer
    AllocationService --> DatabaseInitializer
    PaymentService --> DatabaseInitializer
```

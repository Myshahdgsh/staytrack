USE staytrack_db;

INSERT INTO students(full_name, father_name, mother_name, gender, date_of_birth, phone, email, address, admission_date, guardian_contact) VALUES
('Ayesha Rahman', 'Kamal Rahman', 'Nusrat Rahman', 'Female', '2003-04-15', '01711111111', 'ayesha@example.com', 'Dhaka', '2026-01-10', '01811111111'),
('Tanvir Hasan', 'Masud Hasan', 'Salma Hasan', 'Male', '2002-08-21', '01722222222', 'tanvir@example.com', 'Chattogram', '2026-02-01', '01822222222');

INSERT INTO payments(student_id, fee_month, amount, payment_date, due_amount, status) VALUES
(1, '2026-06', 7500.00, '2026-06-02', 0.00, 'Paid'),
(2, '2026-06', 2500.00, '2026-06-02', 3000.00, 'Partially Paid');
